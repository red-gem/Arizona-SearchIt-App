//Icons and sounds from code.org
//Information from Tripadvisor


//All the dropdowns are set to blank at the start of the app
setText("dropdownTypeRestaurant", "");
setText("dropdownSpendingRestaurant", "");
setText("dropdownCityRestaurant", "");
setText("dropdownDayRestaurant", "");
setText("dropdownHomePage", "");
setText("dropdownTypeShopping", "");
setText("dropdownSpendingShopping", "");
setText("dropdownCityShopping", "");
setText("dropdownDayShopping", "");



//Retrieves the data from the library called Activities and sets its columns to lists.
var Name = getColumn("Activities", "Name");
var Type = getColumn("Activities", "Type");
var Spending = getColumn("Activities", "Spending");
var City = getColumn("Activities", "City");
var Description = getColumn("Activities", "Description");
var openSunday = getColumn("Activities", "Sunday Open Time");
var closeSunday = getColumn("Activities", "Sunday Close Time");
var openMonday = getColumn("Activities", "Monday Open Time");
var closeMonday = getColumn("Activities", "Monday Close Time");
var openTuesday = getColumn("Activities", "Tuesday Open Time");
var closeTuesday = getColumn("Activities", "Tuesday Close Time");
var openWednesday = getColumn("Activities", "Wednesday Open Time");
var closeWednesday = getColumn("Activities", "Wednesday Close Time");
var openThursday = getColumn("Activities", "Thursday Open Time");
var closeThursday = getColumn("Activities", "Thursday Close Time");
var openFriday = getColumn("Activities", "Friday Open Time");
var closeFriday = getColumn("Activities", "Friday Close Time");
var openSaturday = getColumn("Activities", "Saturday Open Time");
var closeSaturday = getColumn("Activities", "Saturday Close Time");



//Screen is set to RestaurantAttributes after dropdown is selected from on the HomePage and the search button is clicked.
//Main cities include Phoenix, Tucson, Mesa, Chandler and Glendale.(https://www.whereig.com/usa/states/arizona/cities.html#:~:text=The%20major%20cities%20of%20Arizona%20are%20Phoenix%2C%20Tucson%2C,state%20boundary%2C%20Arizona%20counties%20boundary%20and%20neighbouring%20states).
onEvent("buttonSearchIt_HomePage", "click", function( ) {
  playSound("assets/category_bell/choose_background.mp3", false);
  if (getText("dropdownHomePage") == "Restaurant") {
    setScreen("RestaurantAttributes");
    hideElement("textNoMatches_RestaurantAttributes");
    
  } else if ((getText("dropdownHomePage") == "Shopping")) {
    setScreen("ShoppingAttributes");
    hideElement("textExtraInfobuttonPrevious_ShoppingAttributes");
    
  }
});



//When the homebutton on OutputPage is clicked, the app will return back to the HomePage.
onEvent("buttonBackHome_Output", "click", function( ) {
  setText("dropdownHomePage", "");
  setScreen("HomePage");
  playSound("assets/category_bell/choose_background.mp3", false);
  setText("textAddressOutput", "");
  setText("textOpensOutput", "");
  setText("textClosesOutput", "");
  setText("dropdownHomePage", "");
  setText("dropdownTypeShopping", "");
  setText("dropdownSpendingShopping", "");
  setText("dropdownCityShopping", "");
  setText("dropdownDayShopping", "");
  setText("dropdownTypeRestaurant", "");
  setText("dropdownSpendingRestaurant", "");
  setText("dropdownCityRestaurant", "");
  setText("dropdownDayRestaurant", "");
  
});





//When the back button on RestaurantAttributes is clicked, the app will return back to the previous page which will be the HomePage.
onEvent("buttonPrevious_RestaurantAttributes", "click", function( ) {
  setScreen("HomePage");
  playSound("assets/category_bell/choose_background.mp3", false);
  setText("dropdownHomePage", "");
  hideElement("textNoMatches_RestaurantAttributes");
  setText("dropdownTypeRestaurant", "");
  setText("dropdownSpendingRestaurant", "");
  setText("dropdownCityRestaurant", "");
  setText("dropdownDayRestaurant", "");
  hideElement("textNoMatches_ShoppingAttributes");
});




//When the back button on ShoppingAttributes is clicked, the app will return back the previous page which would be the HomePage.
onEvent("buttonPrevious_ShoppingAttributes", "click", function( ) {
  setScreen("HomePage");
  playSound("assets/category_bell/choose_background.mp3", false);
  setText("dropdownHomePage", "");
  hideElement("textNoMatches_RestaurantAttributes");
  setText("dropdownTypeRestaurant", "");
  setText("dropdownSpendingRestaurant", "");
  setText("dropdownCityRestaurant", "");
  setText("dropdownDayRestaurant", "");
  hideElement("textNoMatches_ShoppingAttributes");
});



//When the SearchIt button on RestaurantAttributes is clicked, the app will find a place based on the 4 attributes inputted on RestaurantAttributes.
onEvent("buttonSearchIt_RestaurantAttributes", "click", function( ) {
  playSound("assets/category_bell/choose_background.mp3", false);
  for (var i = 0; i < Name.length; i++) {
    if (getText("dropdownHomePage") == Type[i] && getText("dropdownTypeRestaurant") == Description[i] && getText("dropdownSpendingRestaurant") == Spending[i] && getText("dropdownCityRestaurant") == City[i]) {
      setScreen("OutputPage");
      var address = getColumn("Activities", "Address");
      var image = getColumn("Activities", "Image");
      setText("Name_OutputPage", Name[i]);
      setText("textAddressOutput", address[i]);
      setImageURL("image_OutputPage", image[i]);
      if (getText("dropdownDayRestaurant") == "Sunday") {
        setText("textOpensOutput", openSunday[i]);
        setText("textClosesOutput", closeSunday[i]);
      } else if ((getText("dropdownDayRestaurant") == "Monday")) {
        setText("textOpensOutput", openMonday[i]);
        setText("textClosesOutput", closeMonday[i]);
      } else if ((getText("dropdownDayRestaurant") == "Tuesday")) {
        setText("textOpensOutput", openTuesday[i]);
        setText("textClosesOutput", closeTuesday[i]);
      } else if ((getText("dropdownDayRestaurant") == "Wednesday")) {
        setText("textOpensOutput", openWednesday[i]);
        setText("textClosesOutput", closeWednesday[i]);
      } else if ((getText("dropdownDayRestaurant") == "Thursday")) {
        setText("textOpensOutput", openThursday[i]);
        setText("textClosesOutput", closeThursday[i]);
      } else if ((getText("dropdownDayRestaurant") == "Friday")) {
        setText("textOpensOutput", openFriday[i]);
        setText("textClosesOutput", closeFriday[i]);
      } else {
        setText("textOpensOutput", openSaturday[i]);
        setText("textClosesOutput", closeSaturday[i]);
      }
    } else {
      showElement("textNoMatches_RestaurantAttributes");
    }
  }
});


//When the SearchIt button on ShoppingAttributes is clicked, the app will find a place based on the 4 attributes inputted on ShoppingAttributes.
onEvent("buttonSearchIt_ShoppingAttributes", "click", function( ) {
  playSound("assets/category_bell/choose_background.mp3", false);
  for (var i = 0; i < Name.length; i++) {
    if (getText("dropdownHomePage") == Type[i] && getText("dropdownTypeShopping") == Description[i] && getText("dropdownSpendingShopping") == Spending[i] && getText("dropdownCityShopping") == City[i]) {
      setScreen("OutputPage");
      setText("Name_OutputPage", Name[i]);
      var address = getColumn("Activities", "Address");
      var image = getColumn("Activities", "Image");
      setText("textAddressOutput", address[i]);
      setImageURL("image_OutputPage", image[i]);
      if (getText("dropdownDayShopping") == "Sunday") {
        setText("textOpensOutput", openSunday[i]);
        setText("textClosesOutput", closeSunday[i]);
      } else if ((getText("dropdownDayShopping") == "Monday")) {
        setText("textOpensOutput", openMonday[i]);
        setText("textClosesOutput", closeMonday[i]);
      } else if ((getText("dropdownDayShopping") == "Tuesday")) {
        setText("textOpensOutput", openTuesday[i]);
        setText("textClosesOutput", closeTuesday[i]);
      } else if ((getText("dropdownDayShopping") == "Wednesday")) {
        setText("textOpensOutput", openWednesday[i]);
        setText("textClosesOutput", closeWednesday[i]);
      } else if ((getText("dropdownDayShopping") == "Thursday")) {
        setText("textOpensOutput", openThursday[i]);
        setText("textClosesOutput", closeThursday[i]);
      } else if ((getText("dropdownDayShopping") == "Friday")) {
        setText("textOpensOutput", openFriday[i]);
        setText("textClosesOutput", closeFriday[i]);
      } else {
        setText("textOpensOutput", openSaturday[i]);
        setText("textClosesOutput", closeSaturday[i]);
      }
    } else {
      showElement("textNoMatches_ShoppingAttributes");
    }
  }
});





//Hides the info that only appears on each screen when you hover over it.
hideElement("textExtraInfoDropdownOne_HomePage");
hideElement("textExtraInfoSearchItButton_HomePage");
hideElement("textExtraInfoHomeButton_OutputPage");
hideElement("textExtraInfoDropDownOne_RestaurantAttributes");
hideElement("textExtraInfoDropDownTwo_RestaurantAttributes");
hideElement("textExtraInfoDropDownThree_RestaurantAttributes");
hideElement("textExtraInfoDropDownFour_RestaurantAttributes");
hideElement("textExtraInfobuttonPrevious_RestaurantAttributes");
hideElement("textExtraInfobuttonSearchIt_RestaurantAttributes");
hideElement("textExtraInfoDropDownOne_ShoppingAttributes");
hideElement("textExtraInfoDropDownTwo_ShoppingAttributes");
hideElement("textExtraInfoDropDownThree_ShoppingAttributes");
hideElement("textExtraInfoDropDownFour_ShoppingAttributes");
hideElement("buttonSearchItOne_ShoppingAttributes");
hideElement("textExtraInfobuttonPrevious_ShoppingAttributes");
hideElement("textExtraInfoNoMatches_RestaurantAttribute");
hideElement("textExtraInfoNoMatches_ShoppinAttribute");
hideElement("textExtraInfotextAddressLabel_OutputPage");
hideElement("textExtraInfotextOpenLabel_OutputPage");
hideElement("textExtraInfotextClosesLabel_OutputPage");





//Shows the element when the user hovers over the dropdownHomePage and hides it when they are no longer hovering over it.
onEvent("dropdownHomePage", "mouseover", function( ) {
  showElement("textExtraInfoDropdownOne_HomePage");
});
onEvent("dropdownHomePage", "mouseout", function( ) {
  hideElement("textExtraInfoDropdownOne_HomePage");
});


//Shows the element when the user hovers over the buttonSearchIt_HomePage and hides it when they are no longer hovering over it.
onEvent("buttonSearchIt_HomePage", "mouseover", function( ) {
  showElement("textExtraInfoSearchItButton_HomePage");
});
onEvent("buttonSearchIt_HomePage", "mouseout", function( ) {
  hideElement("textExtraInfoSearchItButton_HomePage");
});


//Shows the element when the user hovers over the buttonBackHome_Output and hides it when they are no longer hovering over it.
onEvent("buttonBackHome_Output", "mouseover", function( ) {
  showElement("textExtraInfoHomeButton_OutputPage");
});
onEvent("buttonBackHome_Output", "mouseout", function( ) {
  hideElement("textExtraInfoHomeButton_OutputPage");
});


//Shows the element when the user hovers over the dropdownTypeRestaurant and hides it when they are no longer hovering over it.
onEvent("dropdownTypeRestaurant", "mouseover", function( ) {
  showElement("textExtraInfoDropDownOne_RestaurantAttributes");
});
onEvent("dropdownTypeRestaurant", "mouseout", function( ) {
  hideElement("textExtraInfoDropDownOne_RestaurantAttributes");
});


//Shows the element when the user hovers over the dropdownSpendingRestaurant and hides it when they are no longer hovering over it.
onEvent("dropdownSpendingRestaurant", "mouseover", function( ) {
  showElement("textExtraInfoDropDownTwo_RestaurantAttributes");
});
onEvent("dropdownSpendingRestaurant", "mouseout", function( ) {
  hideElement("textExtraInfoDropDownTwo_RestaurantAttributes");
});


//Shows the element when the user hovers over the dropdownCityRestaurant and hides it when they are no longer hovering over it.
onEvent("dropdownCityRestaurant", "mouseover", function( ) {
  showElement("textExtraInfoDropDownThree_RestaurantAttributes");
});
onEvent("dropdownCityRestaurant", "mouseout", function( ) {
  hideElement("textExtraInfoDropDownThree_RestaurantAttributes");
});


//Shows the element when the user hovers over the dropdownDayRestaurant and hides it when they are no longer hovering over it.
onEvent("dropdownDayRestaurant", "mouseover", function( ) {
  showElement("textExtraInfoDropDownFour_RestaurantAttributes");
});
onEvent("dropdownDayRestaurant", "mouseout", function( ) {
  hideElement("textExtraInfoDropDownFour_RestaurantAttributes");
});


//Shows the element when the user hovers over the buttonPrevious_RestaurantAttributes and hides it when they are no longer hovering over it.
onEvent("buttonPrevious_RestaurantAttributes", "mouseover", function( ) {
  showElement("textExtraInfobuttonPrevious_RestaurantAttributes");
});
onEvent("buttonPrevious_RestaurantAttributes", "mouseout", function( ) {
  hideElement("textExtraInfobuttonPrevious_RestaurantAttributes");
});


//Shows the element when the user hovers over the buttonSearchIt_RestaurantAttributes and hides it when they are no longer hovering over it.
onEvent("buttonSearchIt_RestaurantAttributes", "mouseover", function( ) {
  showElement("textExtraInfobuttonSearchIt_RestaurantAttributes");
});
onEvent("buttonSearchIt_RestaurantAttributes", "mouseout", function( ) {
  hideElement("textExtraInfobuttonSearchIt_RestaurantAttributes");
});


//Shows the element when the user hovers over the textNoMatches_RestaurantAttributes and hides it when they are no longer hovering over it.
onEvent("textNoMatches_RestaurantAttributes", "mouseover", function( ) {
  showElement("textExtraInfoNoMatches_RestaurantAttribute");
});
onEvent("textNoMatches_RestaurantAttributes", "mouseout", function( ) {
  hideElement("textExtraInfoNoMatches_RestaurantAttribute");
});





//Shows the element when the user hovers over the dropdownTypeShopping and hides it when they are no longer hovering over it.
onEvent("dropdownTypeShopping", "mouseover", function( ) {
  showElement("textExtraInfoDropDownOne_ShoppingAttributes");
});
onEvent("dropdownTypeShopping", "mouseout", function( ) {
  hideElement("textExtraInfoDropDownOne_ShoppingAttributes");
});


//Shows the element when the user hovers over the dropdownSpendingShopping and hides it when they are no longer hovering over it.
onEvent("dropdownSpendingShopping", "mouseover", function( ) {
  showElement("textExtraInfoDropDownTwo_ShoppingAttributes");
});
onEvent("dropdownSpendingShopping", "mouseout", function( ) {
  hideElement("textExtraInfoDropDownTwo_ShoppingAttributes");
});


//Shows the element when the user hovers over the dropdownCityShopping and hides it when they are no longer hovering over it.
onEvent("dropdownCityShopping", "mouseover", function( ) {
  showElement("textExtraInfoDropDownThree_ShoppingAttributes");
});
onEvent("dropdownCityShopping", "mouseout", function( ) {
  hideElement("textExtraInfoDropDownThree_ShoppingAttributes");
});


//Shows the element when the user hovers over the dropdownDayShopping and hides it when they are no longer hovering over it.
onEvent("dropdownDayShopping", "mouseover", function( ) {
  showElement("textExtraInfoDropDownFour_ShoppingAttributes");
});
onEvent("dropdownDayShopping", "mouseout", function( ) {
  hideElement("textExtraInfoDropDownFour_ShoppingAttributes");
});


//Shows the element when the user hovers over the buttonSearchIt_ShoppingAttributes and hides it when they are no longer hovering over it.
onEvent("buttonSearchIt_ShoppingAttributes", "mouseover", function( ) {
  showElement("buttonSearchItOne_ShoppingAttributes");
});
onEvent("buttonSearchIt_ShoppingAttributes", "mouseout", function( ) {
  hideElement("buttonSearchItOne_ShoppingAttributes");
});


//Shows the element when the user hovers over the buttonPrevious_ShoppingAttributes and hides it when they are no longer hovering over it.
onEvent("buttonPrevious_ShoppingAttributes", "mouseover", function( ) {
  showElement("textExtraInfobuttonPrevious_ShoppingAttributes");
});
onEvent("buttonPrevious_ShoppingAttributes", "mouseout", function( ) {
  hideElement("textExtraInfobuttonPrevious_ShoppingAttributes");
});


//Shows the element when the user hovers over the textNoMatches_ShoppingAttributes and hides it when they are no longer hovering over it.
onEvent("textNoMatches_ShoppingAttributes", "mouseover", function( ) {
  showElement("textExtraInfoNoMatches_ShoppinAttribute");
});
onEvent("textNoMatches_ShoppingAttributes", "mouseout", function( ) {
  hideElement("textExtraInfoNoMatches_ShoppinAttribute");
});

//Shows the element when the user hovers over the textAddressLabel and hides it when they are no longer hovering over it.
onEvent("textAddressLabel", "mouseover", function( ) {
  showElement("textExtraInfotextAddressLabel_OutputPage");
});
onEvent("textAddressLabel", "mouseout", function( ) {
  hideElement("textExtraInfotextAddressLabel_OutputPage");
});

//Shows the element when the user hovers over the textOpensLabel and hides it when they are no longer hovering over it.
onEvent("textOpensLabel", "mouseover", function( ) {
  showElement("textExtraInfotextOpenLabel_OutputPage");
});
onEvent("textOpensLabel", "mouseout", function( ) {
  hideElement("textExtraInfotextOpenLabel_OutputPage");
});

//Shows the element when the user hovers over the textClosesLabel and hides it when they are no longer hovering over it.
onEvent("textClosesLabel", "mouseover", function( ) {
  showElement("textExtraInfotextClosesLabel_OutputPage");
});
onEvent("textClosesLabel", "mouseout", function( ) {
  hideElement("textExtraInfotextClosesLabel_OutputPage");
});




//When the arrow button on the WorksCited page is clicked, the user is sent back to the HomePage.
onEvent("buttonPreviousPage_WorksCited", "click", function( ) {
  playSound("assets/category_bell/choose_background.mp3", false);
  setScreen("HomePage");
  
});

//When the works cited box is clicked on the HomePage, the user is sent to the WorksCited Page.
onEvent("textWorksCited", "click", function( ) {
  playSound("assets/category_bell/choose_background.mp3", false);
  setScreen("WorksCited");
  
});


//When the arrow button on the WorksCited page is clicked, the user is sent back to the HomePage.
onEvent("buttonPrevious_Purpose", "click", function( ) {
  playSound("assets/category_bell/choose_background.mp3", false);
  setScreen("HomePage");
  
});

//When the works cited box is clicked on the HomePage, the user is sent to the WorksCited Page.
onEvent("textPurpose", "click", function( ) {
  playSound("assets/category_bell/choose_background.mp3", false);
  setScreen("Purpose");
  
});



